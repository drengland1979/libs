
import { CognitoUserPool } from 'amazon-cognito-identity-js';

const poolData = {
    UserPoolId: "eu-west-2_tKuUsTMW6",
    ClientId: "1srea6nb4a3ijs8ues0rhk59p6"
}

export default new CognitoUserPool(poolData);