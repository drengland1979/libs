import './App.css';
import React from 'react';
import { Account } from './components/Account';
import Status from './components/Status';
import LandingBody from './components/LandingBody';

function App() {
  return (
    <div className='app'>
        <Account>
          <Status />
            <LandingBody />
        </Account>
    </div>
  );
}

export default App;
