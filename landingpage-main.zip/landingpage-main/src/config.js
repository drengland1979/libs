window._config = {
  cognito: {
      userPoolId: 'eu-west-2_tKuUsTMW6',
      userPoolClientId: '1srea6nb4a3ijs8ues0rhk59p6',
      region: 'eu-west-2'
  },
  api: {
      invokeUrl: ''
  }
};