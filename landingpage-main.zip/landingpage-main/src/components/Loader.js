import React, { CSSProperties } from 'react';
import BeatLoader from "react-spinners/BeatLoader";

const Loader = () => {
  const override: CSSProperties = {
    display: "block",
    margin: "0 auto",
    borderColor: "black",
  };
  return (
    <div id='loader' className="loading-bar">
      <BeatLoader
          color='#ffffff'
          loading='true'
          cssOverride={override}
          size={20}
          aria-label="Loading Spinner"
          data-testid="loader"
      />
    </div>
  );
};
export default Loader;