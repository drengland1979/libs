import React, { useState, useEffect, useContext } from 'react';
import { AccountContext } from './Account';
import Login from './Login';
import Loader from './Loader';
import Toolbar from './Toolbar';
import './LandingBody.css';

const LandingPage = () => {
    const [loggedIn, setLoggedIn] = useState(false);
    const [loading, setLoading] = useState(false);
    const { getSession, logout } = useContext(AccountContext);
    const logoutClick = (event) => {
        setLoading(true);
        logout();
    }
    useEffect(() => {
        getSession()
            .then(() => {
                setLoggedIn(true);
            });
    });
    return (
        <div>
            {loggedIn && (
                <div className='main-container'>
                    <Toolbar />
                    <p>This is the Sensorium Landing Page</p>
                    <br />
                    {loading ? 
                        <Loader /> 
                    :
                        <button onClick={logoutClick}>Logout</button>
                    }
                </div>
            )}
            {!loggedIn && (
                <div>
                    <Login />
                </div>
            )}
        </div>
    );
};
export default LandingPage;