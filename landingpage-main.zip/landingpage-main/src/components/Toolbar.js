import './Toolbar.css';

const Toolbar = () => {
    return (
      <div class='toolbar-container'>
          This is the Sensorium Toolbar
      </div>
    );
};
export default Toolbar;