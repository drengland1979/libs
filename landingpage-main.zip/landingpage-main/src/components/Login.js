import React, { useState, useContext } from 'react';
import { AccountContext } from './Account';
import Loader from './Loader';
import './Login.css';

const Login = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [loading, setLoading] = useState(false);
    const { authenticate } = useContext(AccountContext);

    const onSubmit = (event) => {
        event.preventDefault();

        setLoading(!loading);
        document.getElementById('loginBtn').disabled = true;

        authenticate(email, password)
            .then(data => {
                console.log("Logged In!", data);
                window.location.reload(false);
            })
            .catch(err => {
                console.log("Failed to login", err);
                document.getElementById('loginBtn').disabled = false;
            })
    };
    return (
        <div className='login-container'>
            <form onSubmit={onSubmit}>
                <label htmlFor='email'>Email: </label>
                <input
                    value={email}
                    onChange={(event) => setEmail(event.target.value)}
                ></input>
                <br/>
                <label htmlFor='password'>Password: </label>
                <input
                    type='password'
                    autoComplete="off"
                    value={password}
                    onChange={(event) => setPassword(event.target.value)}
                ></input>
                <br/><br/>
                {loading ?
                    <Loader />
                :
                    <button id='loginBtn' type='submit'>Login</button>
                }
            </form>
        </div>
    );
};

export default Login;